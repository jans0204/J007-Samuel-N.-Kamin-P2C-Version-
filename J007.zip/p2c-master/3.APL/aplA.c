/* Output from p2c 2.00.Oct.15, the Pascal-to-C translator */
/* From input file "aplA.p" */


/*****************************************************************
 *                     DECLARATIONS                              *
 *****************************************************************/

#include <p2c/p2c.h>


#define NAMELENG        20   /* Maximum length of a name */
#define MAXNAMES        100   /* Maximum number of different names */
#define MAXINPUT        500   /* Maximum length of an input */

#define PROMPT          "-> "
#define PROMPT2         "> "

#define COMMENTCHAR     ';'

#define TABCODE         9   /* in ASCII */


typedef char NAMESIZE;

typedef Char NAMESTRING[NAMELENG];

typedef char NAME;
   /* a NAME is an index in printNames */

typedef enum {
  IFOP, WHILEOP, SETOP, BEGINOP, PLUSOP, MINUSOP, TIMESOP, DIVOP, MAXOP, OROP,
  ANDOP, EQOP, LTOP, GTOP, REDPLUSOP, REDMINUSOP, REDTIMESOP, REDDIVOP,
  REDMAXOP, REDOROP, REDANDOP, COMPRESSOP, SHAPEOP, RAVELOP, RESTRUCTOP,
  CATOP, INDXOP, TRANSOP, SUBOP, PRINTOP
} BUILTINOP;
typedef BUILTINOP VALUEOP;

typedef BUILTINOP CONTROLOP;

typedef BUILTINOP REDOP;



typedef enum {
  SCALAR, VECTOR, MATRIX
} RANK;

typedef struct APLVALUEREC {
  struct INTLISTREC *intvals;
  RANK rnk;
  union {
    long leng;
    struct {
      long rows, cols;
    } U2;
  } UU;
} APLVALUEREC;

typedef struct INTLISTREC {
  long int_;
  struct INTLISTREC *nextint;
} INTLISTREC;

typedef enum {
  VALEXP, VAREXP, APEXP
} EXPTYPE;

typedef struct EXPREC {
  EXPTYPE etype;
  union {
    APLVALUEREC *aplval;
    NAME varble;
    struct {
      NAME optr;
      struct EXPLISTREC *args;
    } U2;
  } UU;
} EXPREC;

typedef struct EXPLISTREC {
  EXPREC *head;
  struct EXPLISTREC *tail;
} EXPLISTREC;

typedef struct VALUELISTREC {
  APLVALUEREC *head;
  struct VALUELISTREC *tail;
} VALUELISTREC;

typedef struct NAMELISTREC {
  NAME head;
  struct NAMELISTREC *tail;
} NAMELISTREC;

typedef struct ENVREC {
  NAMELISTREC *vars;
  VALUELISTREC *values;
} ENVREC;

typedef struct FUNDEFREC {
  NAME funname;
  NAMELISTREC *formals;
  EXPREC *body;
  struct FUNDEFREC *nextfundef;
} FUNDEFREC;


Static FUNDEFREC *fundefs;

Static ENVREC *globalEnv;

Static EXPREC *currentExp;

Static Char userinput[MAXINPUT];
Static short inputleng, pos_;

Static NAMESTRING printNames[MAXNAMES];
Static NAME numNames, numBuiltins;

Static boolean quittingtime;

/* -------------------------------------------------------------------- path */
Static APLVALUEREC *result;


/*****************************************************************
 *                     DATA STRUCTURE OP'S                       *
 *****************************************************************/

/* mkVALEXP - return an EXP of type VALEXP with aplval a         */
Static EXPREC *mkVALEXP(a)
APLVALUEREC *a;
{
  EXPREC *e;

  e = (EXPREC *)Malloc(sizeof(EXPREC));
  e->etype = VALEXP;
  e->UU.aplval = a;
  return e;
}  /* mkVALEXP */


/* mkVAREXP - return an EXP of type VAREXP with varble nm        */
Static EXPREC *mkVAREXP(nm)
NAME nm;
{
  EXPREC *e;

  e = (EXPREC *)Malloc(sizeof(EXPREC));
  e->etype = VAREXP;
  e->UU.varble = nm;
  return e;
}  /* mkVAREXP */


/* mkAPEXP - return EXP of type APEXP w/ optr op and args el     */
Static EXPREC *mkAPEXP(op, el)
NAME op;
EXPLISTREC *el;
{
  EXPREC *e;

  e = (EXPREC *)Malloc(sizeof(EXPREC));
  e->etype = APEXP;
  e->UU.U2.optr = op;
  e->UU.U2.args = el;
  return e;
}  /* mkAPEXP */


/* mkExplist - return an EXPLIST with head e and tail el         */
Static EXPLISTREC *mkExplist(e, el)
EXPREC *e;
EXPLISTREC *el;
{
  EXPLISTREC *newel;

  newel = (EXPLISTREC *)Malloc(sizeof(EXPLISTREC));
  newel->head = e;
  newel->tail = el;
  return newel;
}  /* mkExplist */


/* mkNamelist - return a NAMELIST with head n and tail nl        */
Static NAMELISTREC *mkNamelist(nm, nl)
NAME nm;
NAMELISTREC *nl;
{
  NAMELISTREC *newnl;

  newnl = (NAMELISTREC *)Malloc(sizeof(NAMELISTREC));
  newnl->head = nm;
  newnl->tail = nl;
  return newnl;
}  /* mkNamelist */


/* mkValuelist - return an VALUELIST with head a and tail vl     */
Static VALUELISTREC *mkValuelist(a, vl)
APLVALUEREC *a;
VALUELISTREC *vl;
{
  VALUELISTREC *newvl;

  newvl = (VALUELISTREC *)Malloc(sizeof(VALUELISTREC));
  newvl->head = a;
  newvl->tail = vl;
  return newvl;
}  /* mkValuelist */


/* mkEnv - return an ENV with vars nl and values vl              */
Static ENVREC *mkEnv(nl, vl)
NAMELISTREC *nl;
VALUELISTREC *vl;
{
  ENVREC *rho;

  rho = (ENVREC *)Malloc(sizeof(ENVREC));
  rho->vars = nl;
  rho->values = vl;
  return rho;
}  /* mkEnv */


/* lengthVL - return length of VALUELIST vl                      */
Static long lengthVL(vl)
VALUELISTREC *vl;
{
  long i = 0;

  while (vl != NULL) {
    i++;
    vl = vl->tail;
  }
  return i;
}  /* lengthVL */


/* lengthNL - return length of NAMELIST nl                       */
Static long lengthNL(nl)
NAMELISTREC *nl;
{
  long i = 0;

  while (nl != NULL) {
    i++;
    nl = nl->tail;
  }
  return i;
}  /* lengthNL */


/* lengthIL - return length of INTLIST il                        */
Static long lengthIL(il)
INTLISTREC *il;
{
  long i = 0;

  while (il != NULL) {
    i++;
    il = il->nextint;
  }
  return i;
}  /* lengthIL */


/*****************************************************************
 *                     NAME MANAGEMENT                           *
 *****************************************************************/

/* fetchFun - get function definition of fname from fundefs      */
Static FUNDEFREC *fetchFun(fname)
NAME fname;
{
  FUNDEFREC *f;
  boolean found = false;

  f = fundefs;
  while (f != NULL && !found) {
    if (f->funname == fname)
      found = true;
    else
      f = f->nextfundef;
  }
  return f;
}  /* fetchFun */


/* newFunDef - add new function fname w/ parameters nl, body e   */
Static Void newFunDef(fname, nl, e)
NAME fname;
NAMELISTREC *nl;
EXPREC *e;
{
  FUNDEFREC *f;

  f = fetchFun(fname);
  if (f == NULL) {   /* fname not yet defined as a function */
    f = (FUNDEFREC *)Malloc(sizeof(FUNDEFREC));
    f->nextfundef = fundefs;   /* place new FUNDEFREC */
    fundefs = f;   /* on fundefs list */
  }
  f->funname = fname;
  f->formals = nl;
  f->body = e;
}  /* newFunDef */


/* initNames - place all pre-defined names into printNames       */
Static Void initNames()
{
  long i = 1;

  fundefs = NULL;
  memcpy(printNames[i-1], "if                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "while               ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "set                 ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "begin               ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "+                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "-                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "*                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "/                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "max                 ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "or                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "and                 ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "=                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "<                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], ">                   ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "+/                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "-/                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "*/                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "//                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "max/                ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "or/                 ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "and/                ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "compress            ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "shape               ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "ravel               ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "restruct            ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "cat                 ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "indx                ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "trans               ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "[]                  ", sizeof(NAMESTRING));
  i++;
  memcpy(printNames[i-1], "print               ", sizeof(NAMESTRING));
  numNames = i;
  numBuiltins = i;
}  /* initNames */


Static jmp_buf _JL99;


/* install - insert new name into printNames                     */
Static NAME install(nm)
Char *nm;
{
  long i = 1;
  boolean found = false;

  while (i <= numNames && !found) {
    if (!strncmp(nm, printNames[i-1], sizeof(NAMESTRING)))
      found = true;
    else
      i++;
  }
  if (found)
    return i;
  if (i > MAXNAMES) {
    printf("No more room for names\n");
    longjmp(_JL99, 1);
  }
  numNames = i;
  memcpy(printNames[i-1], nm, sizeof(NAMESTRING));
  return i;
}  /* install */


/* prName - print name nm                                        */
Static Void prName(nm)
NAME nm;
{
  long i = 1;

  while (i <= NAMELENG) {
    if (printNames[nm-1][i-1] != ' ') {
      putchar(printNames[nm-1][i-1]);
      i++;
    } else
      i = NAMELENG + 1;
  }
}  /* prName */


/* primOp - translate NAME optr to corresponding BUILTINOP       */
Static BUILTINOP primOp(optr)
NAME optr;
{
  BUILTINOP op = IFOP;
  long i;

  /* N.B. IFOP is first value in BUILTINOPS */
  for (i = 1; i < optr; i++)
    op = (BUILTINOP)((long)op + 1);
  return op;
}  /* primOp */


/*****************************************************************
 *                        INPUT                                  *
 *****************************************************************/

/* isDelim - check if c is a delimiter                           */
Static boolean isDelim(c)
Char c;
{
  return (c == COMMENTCHAR || c == ' ' || c == ')' || c == '(');
}  /* isDelim */


/* skipblanks - return next non-blank position in userinput      */
Static long skipblanks(p)
long p;
{
  while (userinput[p-1] == ' ')
    p++;
  return p;
}  /* skipblanks */


/* matches - check if string nm matches userinput[s .. s+leng]   */
Static boolean matches(s, leng, nm)
long s;
NAMESIZE leng;
Char *nm;
{
  boolean match = true;
  long i = 1;

  while (match && i <= leng) {
    if (userinput[s-1] != nm[i-1])
      match = false;
    i++;
    s++;
  }
  if (!isDelim(userinput[s-1]))
    match = false;
  return match;
}  /* matches */


/* nextchar - read next char - filter tabs and comments          */
Static Void nextchar(c)
Char *c;
{
  *c = getchar();
  if (*c == '\n')
    *c = ' ';
  if (*c == (Char)TABCODE) {
    *c = ' ';
    return;
  }
  if (*c != COMMENTCHAR)
    return;
  while (!P_eoln(stdin)) {
    *c = getchar();
    if (*c == '\n')
      *c = ' ';
  }
  *c = ' ';
}  /* nextchar */


/* readParens - read char's, ignoring newlines, to matching ')'  */
Static Void readParens()
{
  long parencnt = 1;   /* current depth of parentheses */
  Char c;

  /* '(' just read */
  do {
    if (P_eoln(stdin))
      fputs(PROMPT2, stdout);
    nextchar(&c);
    pos_++;
    if (pos_ == MAXINPUT) {
      printf("User input too long\n");
      longjmp(_JL99, 1);
    }
    userinput[pos_-1] = c;
    if (c == '(')
      parencnt++;
    if (c == ')')
      parencnt--;
  } while (parencnt != 0);   /* readParens */
}


/* readInput - read char's into userinput                        */
Static Void readInput()
{
  Char c;

  fputs(PROMPT, stdout);
  pos_ = 0;
  do {
    pos_++;
    if (pos_ == MAXINPUT) {
      printf("User input too long\n");
      longjmp(_JL99, 1);
    }
    nextchar(&c);
    userinput[pos_-1] = c;
    if (userinput[pos_-1] == '(')
      readParens();
  } while (!P_eoln(stdin));
  inputleng = pos_;
  userinput[pos_] = COMMENTCHAR;   /* sentinel */
}  /* readInput */


/* reader - read char's into userinput; be sure input not blank  */
Static Void reader()
{
  do {
    readInput();
    pos_ = skipblanks(1L);   /* ignore blank lines */
  } while (pos_ > inputleng);   /* reader */
}


/* parseName - return (installed) NAME starting at userinput[pos]*/
Static NAME parseName()
{
  NAMESTRING nm;   /* array to accumulate characters */
  NAMESIZE leng = 0;   /* length of name */

  while ((pos_ <= inputleng) & (!isDelim(userinput[pos_-1]))) {
    if (leng == NAMELENG) {
      printf("Name too long, begins: %.*s\n", NAMELENG, nm);
      longjmp(_JL99, 1);
    }
    leng++;
    nm[leng-1] = userinput[pos_-1];
    pos_++;
  }
  if (leng == 0) {
    printf("Error: expected name, instead read: %c\n", userinput[pos_-1]);
    longjmp(_JL99, 1);
  }
  for (; leng <= NAMELENG - 1; leng++)
    nm[leng] = ' ';
  pos_ = skipblanks((long)pos_);   /* skip blanks after name */
  return (install(nm));
}  /* parseName */


/* isDigits - check if sequence of digits begins at pos          */
Static boolean isDigits(pos)
long pos;
{
  if (!isdigit(userinput[pos-1]))
    return false;
/* p2c: aplA.p: Note: Eliminated unused assignment statement [338] */
  while (isdigit(userinput[pos-1]))
    pos++;
  if (!isDelim(userinput[pos-1]))
    return false;
  return true;
}  /* isDigits */


/* isNumber - check if a number begins at pos                    */
Static boolean isNumber(pos)
long pos;
{
  return (isDigits(pos) | ((userinput[pos-1] == '-') & isDigits(pos + 1)));
}  /* isNumber */


/* isValue - check if a number or vector const begins at pos     */
Static boolean isValue(pos)
long pos;
{
  return ((userinput[pos-1] == '\'') | isNumber(pos));
}  /* isValue */


/* parseInt - return number starting at userinput[pos]            */
Static long parseInt()
{
  long n = 0, sign = 1;

  if (userinput[pos_-1] == '-') {
    sign = -1;
    pos_++;
  }
  while (isdigit(userinput[pos_-1])) {
    n = n * 10 + userinput[pos_-1] - '0';
    pos_++;
  }
  pos_ = skipblanks((long)pos_);   /* skip blanks after number */
  return (n * sign);
}  /* parseInt */


/* parseVec - return INTLIST starting at userinput[pos]           */
Static INTLISTREC *parseVec()
{
  INTLISTREC *il;

  if (userinput[pos_-1] == ')') {
    pos_ = skipblanks(pos_ + 1L);   /* skip ') ...' */
    return NULL;
  }
/* p2c: aplA.p: Note: Eliminated unused assignment statement [338] */
  il = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
  il->int_ = parseInt();
  il->nextint = parseVec();
  return il;
}  /* parseVec */


/* parseVal - return APL value starting at userinput[pos]         */
Static APLVALUEREC *parseVal()
{
  APLVALUEREC *result;

  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  if (userinput[pos_-1] == '\'') {
    result->rnk = VECTOR;
    pos_ = skipblanks(pos_ + 2L);   /* skip "'(..." */
    result->intvals = parseVec();
    result->UU.leng = lengthIL(result->intvals);
    return result;
  }
  result->rnk = SCALAR;
  result->intvals = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
  result->intvals->int_ = parseInt();
  result->intvals->nextint = NULL;
  return result;
}  /* parseVal */


Static EXPLISTREC *parseEL PV();


/* parseExp - return EXP starting at userinput[pos]              */
Static EXPREC *parseExp()
{
  NAME nm;
  EXPLISTREC *el;

  if (userinput[pos_-1] == '(') {  /* APEXP */
    pos_ = skipblanks(pos_ + 1L);   /* skip '( ..' */
    nm = parseName();
    el = parseEL();
    return (mkAPEXP(nm, el));
  } else if (isValue((long)pos_))
    return (mkVALEXP(parseVal()));   /* VALEXP */
  else
    return (mkVAREXP(parseName()));   /* VAREXP */
}  /* parseExp */


/* parseEL - return EXPLIST starting at userinput[pos]           */
Static EXPLISTREC *parseEL()
{
  EXPREC *e;
  EXPLISTREC *el;

  if (userinput[pos_-1] == ')') {
    pos_ = skipblanks(pos_ + 1L);   /* skip ') ..' */
    return NULL;
  } else {
    e = parseExp();
    el = parseEL();
    return (mkExplist(e, el));
  }
}  /* parseEL */


/* parseNL - return NAMELIST starting at userinput[pos]          */
Static NAMELISTREC *parseNL()
{
  NAME nm;
  NAMELISTREC *nl;

  if (userinput[pos_-1] == ')') {
    pos_ = skipblanks(pos_ + 1L);   /* skip ') ..' */
    return NULL;
  } else {
    nm = parseName();
    nl = parseNL();
    return (mkNamelist(nm, nl));
  }
}  /* parseNL */


/* parseDef - parse function definition at userinput[pos]        */
Static NAME parseDef()
{
  NAME fname;   /* function name */
  NAMELISTREC *nl;   /* formal parameters */
  EXPREC *e;   /* body */

  pos_ = skipblanks(pos_ + 1L);   /* skip '( ..' */
  pos_ = skipblanks(pos_ + 6L);   /* skip 'define ..' */
  fname = parseName();
  pos_ = skipblanks(pos_ + 1L);   /* skip '( ..' */
  nl = parseNL();
  e = parseExp();
  pos_ = skipblanks(pos_ + 1L);   /* skip ') ..' */
  newFunDef(fname, nl, e);
  return fname;
}  /* parseDef */


/*****************************************************************
 *                     ENVIRONMENTS                              *
 *****************************************************************/

/* emptyEnv - return an environment with no bindings             */
Static ENVREC *emptyEnv()
{
  return (mkEnv(NULL, NULL));
}  /* emptyEnv */


/* bindVar - bind variable nm to value a in environment rho      */
Static Void bindVar(nm, a, rho)
NAME nm;
APLVALUEREC *a;
ENVREC *rho;
{
  rho->vars = mkNamelist(nm, rho->vars);
  rho->values = mkValuelist(a, rho->values);
}  /* bindVar */


/* findVar - look up nm in rho                                   */
Static VALUELISTREC *findVar(nm, rho)
NAME nm;
ENVREC *rho;
{
  NAMELISTREC *nl;
  VALUELISTREC *vl;
  boolean found = false;

  nl = rho->vars;
  vl = rho->values;
  while (nl != NULL && !found) {
    if (nl->head == nm)
      found = true;
    else {
      nl = nl->tail;
      vl = vl->tail;
    }
  }
  return vl;
}  /* findVar */


/* assign - assign value a to variable nm in rho                 */
Static Void assign(nm, a, rho)
NAME nm;
APLVALUEREC *a;
ENVREC *rho;
{
  VALUELISTREC *varloc;

  varloc = findVar(nm, rho);
  varloc->head = a;
}  /* assign */


/* fetch - return number bound to nm in rho                      */
Static APLVALUEREC *fetch(nm, rho)
NAME nm;
ENVREC *rho;
{
  VALUELISTREC *vl;

  vl = findVar(nm, rho);
  return (vl->head);
}  /* fetch */


/* isBound - check if nm is bound in rho                         */
Static boolean isBound(nm, rho)
NAME nm;
ENVREC *rho;
{
  return (findVar(nm, rho) != NULL);
}  /* isBound */


/*****************************************************************
 *                     APL VALUES                                *
 *****************************************************************/

/* prIntlist - print INTLIST il as dim1 x dim2 matrix            */
Static Void prIntlist(il, dim1, dim2)
INTLISTREC *il;
long dim1, dim2;
{
  long i, j;

  for (i = 1; i <= dim1; i++) {
    for (j = 1; j <= dim2; j++) {
      printf("%6ld ", il->int_);
      il = il->nextint;
    }
    putchar('\n');
  }
}  /* prIntlist */


/* prValue - print APL value a                                   */
Static Void prValue(a)
APLVALUEREC *a;
{
  switch (a->rnk) {

  case SCALAR:
    prIntlist(a->intvals, 1L, 1L);
    break;

  case VECTOR:
    prIntlist(a->intvals, 1L, a->UU.leng);
    break;

  case MATRIX:
    prIntlist(a->intvals, a->UU.U2.rows, a->UU.U2.cols);
    break;
  }
}  /* prValue */


/* isTrueVal - return true if first value in a is one            */
Static boolean isTrueVal(a)
APLVALUEREC *a;
{
  if (a->intvals == NULL)
    return false;
  else
    return (a->intvals->int_ == 1);
}  /* isTrueVal */


/* size - return number of elements in a                         */
Static long size(a)
APLVALUEREC *a;
{
  long Result;

  switch (a->rnk) {

  case SCALAR:
    Result = 1;
    break;

  case VECTOR:
    Result = a->UU.leng;
    break;

  case MATRIX:
    Result = a->UU.U2.rows * a->UU.U2.cols;
    break;
  }
  return Result;
}  /* size */


/* skipover - return pointer to nth record in il                 */
Static INTLISTREC *skipover(n, il)
long n;
INTLISTREC *il;
{
  while (n > 0) {
    il = il->nextint;
    n--;
  }
  return il;
}  /* skipover */


/* copyrank - copy rank and shape of a to r                      */
Static Void copyrank(a, r)
APLVALUEREC *a, *r;
{
  r->rnk = a->rnk;
  switch (r->rnk) {

  case SCALAR:
    /* blank case */
    break;

  case VECTOR:
    r->UU.leng = a->UU.leng;
    break;

  case MATRIX:
    r->UU.U2.rows = a->UU.U2.rows;
    r->UU.U2.cols = a->UU.U2.cols;
    break;
  }
}  /* copyrank */


/* applyOp - apply VALUEOP op to integer arguments               */
Static long applyOp(op, i, j)
BUILTINOP op;
long i, j;
{
  long Result;

  switch (op) {

  case PLUSOP:
    Result = i + j;
    break;

  case MINUSOP:
    Result = i - j;
    break;

  case TIMESOP:
    Result = i * j;
    break;

  case DIVOP:
    Result = i / j;
    break;

  case MAXOP:
    if (i > j)
      Result = i;
    else
      Result = j;
    break;

  case OROP:
    if (i == 1 || j == 1)
      Result = 1;
    else
      Result = 0;
    break;

  case ANDOP:
    if (i == 1 && j == 1)
      Result = 1;
    else
      Result = 0;
    break;

  case EQOP:
    if (i == j)
      Result = 1;
    else
      Result = 0;
    break;

  case LTOP:
    if (i < j)
      Result = 1;
    else
      Result = 0;
    break;

  case GTOP:
    if (i > j)
      Result = 1;
    else
      Result = 0;
    break;
  }
  return Result;
}  /* applyOp */


/* applyIntlis - apply op to two lists, extending appropriately  */
Static INTLISTREC *applyIntlis(op, il1, il2, il1leng, il2leng)
BUILTINOP op;
INTLISTREC *il1, *il2;
long il1leng, il2leng;
{
  INTLISTREC *il;

  if (il1 == NULL || il2 == NULL)
    return NULL;
  else {
    il = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    il->int_ = applyOp(op, il1->int_, il2->int_);
    if (il1leng == 1) {
      il->nextint = applyIntlis(op, il1, il2->nextint, il1leng, il2leng);
      return il;
    }
    if (il2leng == 1)
      il->nextint = applyIntlis(op, il1->nextint, il2, il1leng, il2leng);
    else
      il->nextint = applyIntlis(op, il1->nextint, il2->nextint, il1leng,
				il2leng);
    return il;
  }
}  /* applyIntlis */


/* applyArithOp - apply binary operator to a1 and a2             */
Static Void applyArithOp(op, a1, a2)
BUILTINOP op;
APLVALUEREC *a1, *a2;
{
  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  if (a1->rnk == SCALAR)
    copyrank(a2, result);
  else if (a2->rnk == SCALAR)
    copyrank(a1, result);
  else if (size(a1) == 1)
    copyrank(a2, result);
  else
    copyrank(a1, result);
  result->intvals = applyIntlis(op, a1->intvals, a2->intvals, size(a1),
				size(a2));
}  /* applyArithOp */


/* applyOp - apply base operator of reduction operator           */
Static long applyOp2(op, i, j)
BUILTINOP op;
long i, j;
{
  /* patch */
  long Result;

  switch (op) {

  case REDPLUSOP:
    Result = i + j;
    break;

  case REDMINUSOP:
    Result = i - j;
    break;

  case REDTIMESOP:
    Result = i * j;
    break;

  case REDDIVOP:
    Result = i / j;
    break;

  case REDMAXOP:
    if (i > j)
      Result = i;
    else
      Result = j;
    break;

  case REDOROP:
    if (i == 1 || j == 1)
      Result = 1;
    else
      Result = 0;
    break;

  case REDANDOP:
    if (i == 1 && j == 1)
      Result = 1;
    else
      Result = 0;
    break;
  }
  return Result;
}  /* applyOp */


/* redVec - reduce op (argument to applyRedOp) over list         */
Static long redVec(op, il, leng)
REDOP op;
INTLISTREC *il;
long leng;
{
  /* patch */
  if (leng == 0)
    return 0;
  else if (leng == 1)
    return (il->int_);
  else
    return (applyOp2(op, il->int_, redVec(op, il->nextint, leng - 1)));
	/* patch */
}  /* redVec */


/* redMat - reduce op (argument to applyRedOp) over matrix       */
Static INTLISTREC *redMat(op, il, cols, rows)
REDOP op;
INTLISTREC *il;
long cols, rows;
{
  /* patch */
  INTLISTREC *ilnew;

  if (rows == 0)
    return NULL;
  else {   /* patch */
    ilnew = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    ilnew->int_ = redVec(op, il, cols);
    ilnew->nextint = redMat(op, skipover(cols, il), cols, rows - 1);
	/* patch */
    return ilnew;
  }
}  /* redmat */


/* applyRedOp - apply reduction operator                         */
Static Void applyRedOp(op, a)
REDOP op;
APLVALUEREC *a;
{
  APLVALUEREC *WITH;

  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  switch (a->rnk) {

  case SCALAR:
    result = a;
    break;

  case VECTOR:
    WITH = result;
    WITH->rnk = SCALAR;
    WITH->intvals = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    WITH->intvals->int_ = redVec(op, a->intvals, a->UU.leng);   /* patch */
    WITH->intvals->nextint = NULL;
    break;

  case MATRIX:
    WITH = result;
    WITH->rnk = VECTOR;
    WITH->UU.leng = a->UU.U2.rows;
    WITH->intvals = redMat(op, a->intvals, a->UU.U2.cols, WITH->UU.leng);
	/* patch */
    break;
  }
}  /* applyRedOp */


/* append - append il2 to il1; il1 is altered                    */
Static INTLISTREC *append(il1, il2)
INTLISTREC *il1, *il2;
{
  INTLISTREC *Result;

  if (il1 == NULL)
    return il2;
  Result = il1;
  while (il1->nextint != NULL)
    il1 = il1->nextint;
  il1->nextint = il2;
  return Result;
}  /* append */


/* ncopy - copy elements of src until list has reps elements     */
Static INTLISTREC *ncopy(src, reps)
INTLISTREC *src;
long reps;
{
  INTLISTREC *Result, *il, *suffix;
  long i;

  if (reps == 0)
    return NULL;
  il = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
  Result = il;
  il->int_ = src->int_;
  suffix = src->nextint;
  for (i = 2; i <= reps; i++) {
    if (suffix == NULL)   /* exhausted src */
      suffix = src;
    /* start over */
    il->nextint = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    il = il->nextint;
    il->int_ = suffix->int_;
    suffix = suffix->nextint;
  }
  il->nextint = NULL;
  return Result;
}  /* ncopy */


/* ilcompress - il1 over il2, taking il2 in chunks of size width */
Static INTLISTREC *ilcompress(il1, il2, width)
INTLISTREC *il1, *il2;
long width;
{
  INTLISTREC *il;

  if (il1 == NULL)
    return NULL;
  else if (il1->int_ == 1) {
    il = ncopy(il2, width);
    il = append(il, ilcompress(il1->nextint, skipover(width, il2), width));
    return il;
  } else
    return (ilcompress(il1->nextint, skipover(width, il2), width));
}  /* ilcompress */


/* countones - count ones in il                                  */
Static long countones(il)
INTLISTREC *il;
{
  long i = 0;

  while (il != NULL) {
    if (il->int_ == 1)
      i++;
    il = il->nextint;
  }
  return i;
}  /* countones */


/* compress - compress a1 over a2                                */
Static Void compress(a1, a2)
APLVALUEREC *a1, *a2;
{
  long width;
  APLVALUEREC *WITH;

  if (a2->rnk == VECTOR)
    width = 1;
  else
    width = a2->UU.U2.cols;
  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  WITH = result;
  WITH->rnk = a2->rnk;
  WITH->intvals = ilcompress(a1->intvals, a2->intvals, width);
  if (WITH->rnk == VECTOR)
    WITH->UU.leng = countones(a1->intvals);
  else {
    WITH->UU.U2.cols = a2->UU.U2.cols;
    WITH->UU.U2.rows = countones(a1->intvals);
  }
}  /* compress */


/* shape - return vector giving dimensions of a                  */
Static Void shape(a)
APLVALUEREC *a;
{
  INTLISTREC *il;

  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  result->rnk = VECTOR;
  switch (a->rnk) {

  case SCALAR:
    result->UU.leng = 0;
    result->intvals = NULL;
    break;

  case VECTOR:
    result->UU.leng = 1;
    il = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    result->intvals = il;
    il->int_ = a->UU.leng;
    il->nextint = NULL;
    break;

  case MATRIX:
    result->UU.leng = 2;
    il = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    result->intvals = il;
    il->int_ = a->UU.U2.rows;
    il->nextint = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    il = il->nextint;
    il->int_ = a->UU.U2.cols;
    il->nextint = NULL;
    break;
  }
}  /* shape */


/* ravel - transform a to a vector without changing elements     */
Static Void ravel(a)
APLVALUEREC *a;
{
  long size;
  APLVALUEREC *WITH;

  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  switch (a->rnk) {

  case SCALAR:
    size = 1;
    break;

  case VECTOR:
    size = a->UU.leng;
    break;

  case MATRIX:
    size = a->UU.U2.rows * a->UU.U2.cols;
    break;
  }
  WITH = result;
  WITH->rnk = VECTOR;
  WITH->UU.leng = size;
  WITH->intvals = a->intvals;
}  /* ravel */


/* restruct - restructure valuevec according to shapevec         */
Static Void restruct(shapevec, valuevec)
APLVALUEREC *shapevec, *valuevec;
{
  RANK newrank;
  long dim1, dim2;
  APLVALUEREC *WITH;

  if (valuevec->intvals == NULL) {
    printf("Cannot restructure null vector\n");
    longjmp(_JL99, 1);
  }
  if (shapevec->rnk == SCALAR) {
    newrank = VECTOR;
    dim1 = shapevec->intvals->int_;
    dim2 = 1;
  } else if (shapevec->UU.leng == 0) {
    newrank = SCALAR;
    dim1 = 1;
    dim2 = 1;
  } else if (shapevec->UU.leng == 1) {
    newrank = VECTOR;
    dim1 = shapevec->intvals->int_;
    dim2 = 1;
  } else {
    newrank = MATRIX;
    dim1 = shapevec->intvals->int_;
    dim2 = shapevec->intvals->nextint->int_;
  }
  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  WITH = result;
  WITH->rnk = newrank;
  if (WITH->rnk == VECTOR)
    WITH->UU.leng = dim1;
  else if (WITH->rnk == MATRIX) {
    WITH->UU.U2.rows = dim1;
    WITH->UU.U2.cols = dim2;
  }
  WITH->intvals = ncopy(valuevec->intvals, dim1 * dim2);
}  /* restruct */


/* copyIntlis - make a fresh copy of il                          */
Static INTLISTREC *copyIntlis(il)
INTLISTREC *il;
{
  return (ncopy(il, lengthIL(il)));
}  /* copyIntlis */


/* cat - create a vector by joining ravels of a1 and a2          */
Static Void cat(a1, a2)
APLVALUEREC *a1, *a2;
{
  APLVALUEREC *WITH;

  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  WITH = result;
  WITH->rnk = VECTOR;
  WITH->UU.leng = size(a1) + size(a2);
  WITH->intvals = copyIntlis(a1->intvals);
  WITH->intvals = append(WITH->intvals, a2->intvals);
}  /* cat */


/* indx - perform index generation, using first value in a       */
Static Void indx(a)
APLVALUEREC *a;
{
  long i;
  INTLISTREC *il;
  APLVALUEREC *WITH;

  i = a->intvals->int_;
  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  WITH = result;
  WITH->rnk = VECTOR;
  WITH->intvals = NULL;
  WITH->UU.leng = i;
  while (i > 0) {
    il = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
    il->int_ = i;
    il->nextint = WITH->intvals;
    WITH->intvals = il;
    i--;
  }
}  /* indx */


/* skiplist - subscript il by cols and rows                      */
Static INTLISTREC *skiplist(il, cols, rows)
INTLISTREC *il;
long cols, rows;
{
  INTLISTREC *ilnew;

  ilnew = (INTLISTREC *)Malloc(sizeof(INTLISTREC));
  if (rows == 1) {
    ilnew->int_ = il->int_;
    ilnew->nextint = NULL;
  } else {
    ilnew->int_ = il->int_;
    ilnew->nextint = skiplist(skipover(cols, il), cols, rows - 1);
  }
  return ilnew;
}  /* skiplist */


/* trans - perform "trans"                                       */
Static Void trans(a)
APLVALUEREC *a;
{
  INTLISTREC *il;
  INTLISTREC *ilnew = NULL;
  long i;
  APLVALUEREC *WITH;
  long FORLIM;

  if (a->rnk != MATRIX || a->intvals == NULL) {
    result = a;
    return;
  }
  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  WITH = result;
  WITH->rnk = MATRIX;
  WITH->UU.U2.cols = a->UU.U2.rows;
  WITH->UU.U2.rows = a->UU.U2.cols;
  il = a->intvals;
  FORLIM = WITH->UU.U2.rows;
  for (i = 1; i <= FORLIM; i++) {
    ilnew = append(ilnew, skiplist(il, WITH->UU.U2.rows, WITH->UU.U2.cols));
    il = il->nextint;
  }
  WITH->intvals = ilnew;
}  /* trans */


/* sub - find nth chunk in il, each chunk having width elements  */
Static INTLISTREC *sub(il, n, width)
INTLISTREC *il;
long n, width;
{
  long i, j;

  for (i = 1; i < n; i++) {
    for (j = 1; j <= width; j++)
      il = il->nextint;
  }
  return il;
}  /* sub */


/* ilsub - subscript src by subs in chunks of size width         */
Static INTLISTREC *ilsub(src, subs, width)
INTLISTREC *src, *subs;
long width;
{
  INTLISTREC *il;

  if (subs == NULL)
    return NULL;
/* p2c: aplA.p: Note: Eliminated unused assignment statement [338] */
  il = sub(src, subs->int_, width);
  il = ncopy(il, width);
  il = append(il, ilsub(src, subs->nextint, width));
  return il;
}  /* ilsub */


/* subscript - "[]" operation; a1 a vector or matrix, a2 vector  */
Static Void subscript(a1, a2)
APLVALUEREC *a1, *a2;
{
  long width;
  APLVALUEREC *WITH;

  result = (APLVALUEREC *)Malloc(sizeof(APLVALUEREC));
  WITH = result;
  WITH->rnk = a1->rnk;
  if (WITH->rnk == VECTOR) {
    if (a2->rnk == SCALAR)
      WITH->UU.leng = 1;
    else
      WITH->UU.leng = a2->UU.leng;
    width = 1;
  } else {
    if (a2->rnk == SCALAR)
      WITH->UU.U2.rows = 1;
    else
      WITH->UU.U2.rows = a2->UU.leng;
    WITH->UU.U2.cols = a1->UU.U2.cols;
    width = WITH->UU.U2.cols;
  }
  WITH->intvals = ilsub(a1->intvals, a2->intvals, width);
}  /* subscript */


/* arity - return number of arguments expected by op             */
Static long arity(op)
VALUEOP op;
{
  if (((1L << ((long)op)) & (((1L << ((long)GTOP + 1)) - (1L << ((long)PLUSOP))) |
	 (1L << ((long)COMPRESSOP)) | (1L << ((long)RESTRUCTOP)) |
	 (1L << ((long)CATOP)) | (1L << ((long)SUBOP)))) != 0)
    return 2;
  else
    return 1;
}  /* arity */


/* applyValueOp - apply VALUEOP op to arguments in VALUELIST vl  */
Static APLVALUEREC *applyValueOp(op, vl)
VALUEOP op;
VALUELISTREC *vl;
{
  APLVALUEREC *a1, *a2;

  /* result: APLVALUE;(* patch */
  if (arity(op) != lengthVL(vl)) {
    printf("Wrong number of arguments to ");
    prName((int)op + 1);
    putchar('\n');
    longjmp(_JL99, 1);
  }
  a1 = vl->head;   /* 1st actual */
  if (arity(op) == 2)   /* 2nd actual */
    a2 = vl->tail->head;
  switch (op) {

  case PLUSOP:
  case MINUSOP:
  case TIMESOP:
  case DIVOP:
  case MAXOP:
  case OROP:
  case ANDOP:
  case EQOP:
  case LTOP:
  case GTOP:
    applyArithOp(op, a1, a2);
    break;

  case REDPLUSOP:
  case REDMINUSOP:
  case REDTIMESOP:
  case REDDIVOP:
  case REDMAXOP:
  case REDOROP:
  case REDANDOP:
    applyRedOp(op, a1);
    break;

  case COMPRESSOP:
    compress(a1, a2);
    break;

  case SHAPEOP:
    shape(a1);
    break;

  case RAVELOP:
    ravel(a1);
    break;

  case RESTRUCTOP:
    restruct(a1, a2);
    break;

  case CATOP:
    cat(a1, a2);
    break;

  case INDXOP:
    indx(a1);
    break;

  case TRANSOP:
    trans(a1);
    break;

  case SUBOP:
    subscript(a1, a2);
    break;

  case PRINTOP:
    prValue(a1);
    result = a1;
    break;
  }
  return result;
}  /* applyValueOp */


/*****************************************************************
 *                     EVALUATION                                *
 *****************************************************************/

Static APLVALUEREC *eval PP((EXPREC *e, ENVREC *rho));


/* patch */

/* evalList - evaluate each expression in el                     */
Static VALUELISTREC *evalList(el, rho)
EXPLISTREC *el;
ENVREC *rho;
{
  /* patch */
  APLVALUEREC *h;
  VALUELISTREC *t;

  if (el == NULL)
    return NULL;
  else {   /* patch */
    h = eval(el->head, rho);
    t = evalList(el->tail, rho);
    return (mkValuelist(h, t));
  }
}  /* evalList */


/* applyUserFun - look up definition of nm and apply to actuals  */
Static APLVALUEREC *applyUserFun(nm, actuals)
NAME nm;
VALUELISTREC *actuals;
{
  FUNDEFREC *f;
  ENVREC *rho;

  f = fetchFun(nm);
  if (f == NULL) {
    printf("Undefined function: ");
    prName(nm);
    putchar('\n');
    longjmp(_JL99, 1);
  }
  if (lengthNL(f->formals) != lengthVL(actuals)) {
    printf("Wrong number of arguments to: ");
    prName(nm);
    putchar('\n');
    longjmp(_JL99, 1);
  }
  rho = mkEnv(f->formals, actuals);
  return (eval(f->body, rho));
}  /* applyUserFun */


/* applyCtrlOp - apply CONTROLOP op to args in rho               */
Static APLVALUEREC *applyCtrlOp(op, args, rho)
CONTROLOP op;
EXPLISTREC *args;
ENVREC *rho;
{
  /* patch */
  APLVALUEREC *Result, *a;
  EXPLISTREC *WITH = args;

  switch (op) {

  case IFOP:
    if (isTrueVal(eval(WITH->head, rho)))
      Result = eval(WITH->tail->head, rho);
    else
      Result = eval(WITH->tail->tail->head, rho);
    break;

  case WHILEOP:
    a = eval(WITH->head, rho);
    while (isTrueVal(a)) {
      eval(WITH->tail->head, rho);
/* p2c: aplA.p: Note: Eliminated unused assignment statement [338] */
      a = eval(WITH->head, rho);
    }
    Result = a;
    break;

  case SETOP:
    a = eval(WITH->tail->head, rho);
    if (isBound(WITH->head->UU.varble, rho))
      assign(WITH->head->UU.varble, a, rho);
    else if (isBound(WITH->head->UU.varble, globalEnv))
      assign(WITH->head->UU.varble, a, globalEnv);
    else
      bindVar(WITH->head->UU.varble, a, globalEnv);
    Result = a;
    break;

  case BEGINOP:
    while (args->tail != NULL) {
      eval(args->head, rho);
/* p2c: aplA.p: Note: Eliminated unused assignment statement [338] */
      args = args->tail;
    }
    Result = eval(args->head, rho);
    break;
  }/* case and with */
  return Result;
}  /* applyCtrlOp */


/* eval - return value of expression e in local environment rho  */
Static APLVALUEREC *eval(e, rho)
EXPREC *e;
ENVREC *rho;
{
  APLVALUEREC *Result;
  BUILTINOP op;

  switch (e->etype) {

  case VALEXP:
    Result = e->UU.aplval;
    break;

  case VAREXP:
    if (isBound(e->UU.varble, rho))
      Result = fetch(e->UU.varble, rho);
    else if (isBound(e->UU.varble, globalEnv))
      Result = fetch(e->UU.varble, globalEnv);
    else {
      printf("Undefined variable: ");
      prName(e->UU.varble);
      putchar('\n');
      longjmp(_JL99, 1);
    }
    break;

  case APEXP:
    if (e->UU.U2.optr > numBuiltins)
      Result = applyUserFun(e->UU.U2.optr, evalList(e->UU.U2.args, rho));
	  /* patch */
    else {
      op = primOp(e->UU.U2.optr);
      if (((1L << ((long)op)) &
	   ((1L << ((long)BEGINOP + 1)) - (1L << ((long)IFOP)))) != 0)
	Result = applyCtrlOp(op, e->UU.U2.args, rho);   /* patch */
      else
	Result = applyValueOp(op, evalList(e->UU.U2.args, rho));   /* patch */
    }
    break;
  }/* case and with */
  return Result;
}  /* eval */


/*****************************************************************
 *                     READ-EVAL-PRINT LOOP                      *
 *****************************************************************/

main(argc, argv)
int argc;
Char *argv[];
{  /* apl main */
  PASCAL_MAIN(argc, argv);
  if (setjmp(_JL99))
    goto _L99;
  initNames();
  globalEnv = emptyEnv();

  quittingtime = false;
_L99:
  while (!quittingtime) {
    reader();
    if (matches((long)pos_, 4, "quit                ")) {
      quittingtime = true;
      break;
    }
    if ((userinput[pos_-1] == '(') & matches(skipblanks(pos_ + 1L), 6,
					     "define              ")) {
      prName(parseDef());
      putchar('\n');
    } else {
      currentExp = parseExp();
      prValue(eval(currentExp, emptyEnv()));
      printf("\n\n");
    }
  }
  exit(EXIT_SUCCESS);
}  /* apl */






/* End. */
